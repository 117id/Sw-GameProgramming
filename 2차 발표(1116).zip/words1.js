var words = [
	 "apple", "banana","coconut","eggplant","pepper","onion","garlic",
	 "animal","beginner","cat","door","electric","flag","garbage","horse"
	  ];